package com.Word_Count.www;

/** Node class starting code. 
 *  COMP 2503 Winter 2018
 */
public class Node<T extends Comparable<T>>
{
   
    private T data;
    private Node<T> next;
    
    /**
     * Constructor for objects of class Node
     */
    public Node()
    {
       data = null;
       next = null;
    }
    
    public T getData() 
    {
    	return data;
    	
    }
    public void setData(T o) 
    
    {
    	data = o;
    	
    }
    
    public Node<T> getNext()
    {
    	return next;
    	
    }
    public void setNext(Node<T> n)
    { 
    	next = n;
    	
    }
 
    public String toString() 
    {
        return "Node: " + getData();
    }
}
