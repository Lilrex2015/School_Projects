package com.Word_Count.www;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.*;
public class Word implements Comparable<Word>, Comparator<Word> {
	
	

	private String word;
	private int count;
	
	
	public Word()
	{	}

 
	public Word (String f, int x)
	{
		this.word = f;
		this.count = x;
		
	}

	public String getWord() {
		
		return word;
	}

	public void setWord(String word) {
		this.word = word;
	}

	public int getCount() {
		return count;
	}

	public void setCount(int count) {
		this.count = getCount() + 1;
	}



	
	public int compareTo(Word x) {
		return this.word.compareTo(x.getWord());
	}
	
	

	public int compare(Word item1, Word item2) {
	return item1.getWord().compareTo(item2.getWord());
		

	}

	public boolean equals( Word other) 
	{
		{if ( other == this) 
		
		{
			return true;
		}
			if ( other == null) 
		
			{
				return false;
		
			}
			
		Word w = (Word) other;
		
		return this.getWord().equals( w.getWord());
		
		}


	
}
	
	public boolean isEmpty(ArrayList<Word> words)
	{
		boolean listSize = false;
		
		if(words.size() ==  0)
		{
			listSize = true;
			
			return listSize;
		}
		
		else {
			return listSize;
		}
	}
	
	public String toString()
	{
		String show = "" + this.word + " : "  + this.count;
		return show;
	}

	public Comparator<Word> getMostComparator() {
		
		Comparator<Word> most = new Comparator<Word>() {
			
			public int compare(Word o1, Word o2) {
				Integer int1 = o1.getCount();
				Integer int2 = o2.getCount();

				int tie = int2.compareTo(int1);
				if(tie == 0)
				{
					return o1.getWord().compareTo(o2.getWord());
				}
				
				else {
					
					return tie;
				}
				
			}
		};
		return most;
		
	}
	
	public Comparator<Word> getLeastComparator() {
		
		Comparator<Word> least = new Comparator<Word>() {
			
			public int compare(Word o1, Word o2) {
				Integer int1 = o1.getCount();
				Integer int2 = o2.getCount();

				int tie = int1.compareTo(int2);
				
				if(tie == 0 )
				{
					return o1.getWord().compareTo(o2.getWord());
				}
				
				else {
					
					return tie;
				}
			}
		};
		return least;
	}

	
}
