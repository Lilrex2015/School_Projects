package com.Word_Count.www;

import java.util.Collection;
import java.util.Comparator;
import java.util.Iterator;
import java.util.List;
import java.util.ListIterator;

public class SLL<T extends Comparable<T>>  {
	
	private Node<T> head;
	private Node<T> sorted;
	
	
	public void addToHead(T word) //took out int arg bc of Word object already having it
	{
		if(isEmpty())
		{
			head.setData(word);
		}	
			
		else
		{
			Node<T> curr = head;
			Node<T>  temp = new Node<T>();
			temp.setData(word);
			temp.setNext(curr);
			head = temp;
			
		}
		
	}


	public void add(T word)
{
	if(isEmpty())
	{
		head = new Node<T>();
		head.setData(word);
	}	
		
	
	else {
		
		Node<T> curr = head;
		
		while(curr.getNext() != null)
		{
			curr = curr.getNext();
		}
		
		Node<T> mover = new Node<T>();
		mover.setData(word);
		curr.setNext(mover);
	}
			
	}

	
	public void clear() {
		
		head = null;
				
	}


	
	public T get(int finder) {
		
		int i = 0;
		Node<T> curr = head;
		
		
		while( i != finder) // this finds a node at a specific index point 
		{
			i++;
			curr = curr.getNext();
		}
		
		T word = curr.getData();
		
		return word;
	}




	public boolean isEmpty()
	{
		return head == null; //this checks to see if the list is empty
	}

	
	public T remove(int value) {
		
		Node<T> curr;
		Node<T> temp1;
		Node<T> temp2;
		curr = head; //curr is acting as the mover, as to not lose the head of the list
		
		for(int i = 0; i < value-1; i++) //doing a -1 so we stop before we reach the index of the node we want to delete
		{
			curr = curr.getNext(); 
		}
		
		temp1 = curr;
		temp2 = curr.getNext().getNext(); // this jumps over the node we want to delete and stores the remaining list
		curr.setNext(null); //this nulls out the specified node for deletion
		temp1.setNext(temp2); // this connects the two sections of the list back together 
		head = temp1;
		
		return null;
	}
	

	
	public int size() {
	
		Node<T> curr = head;
		
		if(head == null)
		{
			return 0;
		}
		
		int i = 1;
		while (curr.getNext() != null )
		{
			i++;
			curr = curr.getNext();
		}
		return i;
	}

	
	
   public void sort()
    {
        // Initialize sorted linked list
        sorted = null;
        Node<T> current = head;
        // Traverse the given linked list and insert every
        // node to sorted
        while (current != null) 
        {
            // Store next for next iteration
            Node<T> next = current.getNext();
            // insert current in sorted linked list
            sortedInsert(current);
            // Update current
            current = next;
        }
        // Update head_ref to point to sorted linked list
        head = sorted;
    }
 
    void sortedInsert(Node<T> newnode) 
    {
        /* Special case for the head end */
        if (sorted == null || sorted.getData().compareTo(newnode.getData()) >= 0) 
        {
            newnode.setNext(sorted);
            sorted = newnode;
        }
        else
        {
            Node<T> current = sorted;
            /* Locate the node before the point of insertion */
            while (current.getNext() != null && current.getNext().getData().compareTo(newnode.getData()) < 0) 
            {
                current = current.getNext();
            }
            newnode.setNext(current.getNext());
            current.setNext(newnode);
        }
    }

    void sort(Comparator<T> c)
    {
        // Initialize sorted linked list
        sorted = null;
        Node<T> current = head;
        // Traverse the given linked list and insert every
        // node to sorted
        while (current != null) 
        {
            // Store next for next iteration
            Node<T> next = current.getNext();
            // insert current in sorted linked list
            sortedInsert(c, current);
            // Update current
            current = next;
        }
        // Redirect head pointer to the newly sorted pointer
        head = sorted;
    }
 
    void sortedInsert(Comparator<T> c, Node<T> newnode) 
    {
        
        if (sorted == null || c.compare(sorted.getData(), newnode.getData()) >= 0) 
        {
            newnode.setNext(sorted);
            sorted = newnode;
        }
        else
        {
            Node<T> current = sorted;
            // Locate the node before the point of insertion 
            while (current.getNext() != null && c.compare(current.getNext().getData(), newnode.getData()) < 0) 
            {
                current = current.getNext();
            }
            newnode.setNext(current.getNext());
            current.setNext(newnode);
        }
    }
    public String toString()
    {
    	String s = "";
    	
        Node<T> current = head;
        // Traverse the given linked list and insert every node to sorted
      
        while (current != null) 
        {
            s += current.getData() + ", "; 
            // Store next for next iteration
            Node<T> next = current.getNext();
            // Update current
            current = next;
        }
    	
    	return s;
    }
}
