package com.Word_Count.www;




	import java.awt.print.Printable;
	import java.io.File;
	import java.io.IOException;
	import java.util.ArrayList;
	import java.util.Arrays;
	import java.util.Collections;
	import java.util.Comparator;
	import java.util.Scanner;

	public class A2 {

		// Word objects are contained in Nodes and nodes are added to the SLL
		// Node(word)--> Node(word)

		//static ArrayList<Word> words = new ArrayList<Word>();
		static Node<Word> nodeWord = new Node<Word>();
		static SLL<Word> sll = new SLL<Word>();
		

		static int value = 1;

		static int totalCount = 0;
		
		static int unique = 0;
		
		static int bannedCount = 0;
		
		
		
		
		public static void main(String[] args) throws IOException {

			
			run();
			
			print();
			
		}

		/*--------------------------------------------------------------------------------------------------------------------*/

		public static void run() throws IOException {

			int i = 0;
			Scanner input = new Scanner(System.in);
			//Scanner input = new Scanner(new File("inp2.txt")); 
			
			while (input.hasNext()) {
				// nextLine gets the word, toLower makes the word lower case , \\w ignores
				// punctuation and \\d ignores numbers
				String text = input.next().toLowerCase().trim().replaceAll("\\W", "").replaceAll("\\d", "");
			

				if (!text.isEmpty()) {
					BannedWordsTest(text);
				}
				
				
				

			}
			

			input.close();
		}

		public static void BannedWordsTest(String text) {
			String bannedWords[] = { "a", "about", "all", "am", "an", "and", "any", "are", "as", "at", "be",
					 "been", "but", "by", "can", "cannot", "could", "did", "do", "does", "else", "for",
					"from", "get", "got", "had", "has", "have", "he", "her",  "hers", "him", "his", "how", "i",
					"if", "in", "into", "is", "it", "its", "like",  "more", "me", "my", "no", "now", "not", "of",
					"on", "one", "or", "our", "out",  "said", "say", "says", "she", "so", "some", "than", "that",
					"the", "their", "them", "then", "there", "these", "they", "this", "to", "too", "us", "upon",
					 "was", "we", "were", "what", "with", "when", "where", "which", "while", "who",  "whom",
					"why", "will", "you", "your" };

		
			
			boolean bannedTest = false;
		 

			// find out if "text" is banned or not
			for (int i = 0; i < bannedWords.length; i++) {
				// get the next banned word
				String h = bannedWords[i];
				
				// is "text" banned? if yes go true 
				if(text.equals(h))
				{
					bannedTest = true;
				}
			}
				// if true stop proceeding and increment counter
			if(bannedTest == true)
			{
				bannedCount++;
				
			}
			
			else {
				// if not banned, proceed to unique word list
				addIn(text);
			}


		}
		


		public static Word addIn(String text) {

			// Word objects are contained in Nodes and nodes are added to the SLL
			// Node(word)--> Node(word)
			
			//Need to compare the new string to the existing list. Must get all nodes, extract node data, for word objects
			// use word.getWord to get the string contents and if a match increase count and repackage, or else make a new node
			
			int size = sll.size(); //this stores the size of the list to make it easier when evaluating the size
			
			for (int t = 0; t < size; t++) {
				
				Word temp = sll.get(t); //this gets the data stored within the node and puts it into a word object
			
				if(temp.getWord().equals(text)) //this does the evaluation comparison of strings to see if the word is in the list already
				{
					int value = temp.getCount() + 1; //if the word is found, it adds 1 to the count of frequency
					temp.setCount(value); //this re-stores the value tot he node
					return temp;
				}
				
				
			
			
			}
			
			Word word = new Word(text , 1); //if the word is not found, make a new node and store it
			sll.add(word); //adds to the list
			
			return word;
			
			
		}

		public static void Sorter(SLL<Word> words) {
			
			//this sorts the list into order
	
			words.sort();

		}
		
		
			
			
			


			
		//------------------------------------------------------------------------------------
		public static void print() {
			//System.out.println(sll);
		
			Word w = new Word();
	        Comparator<Word> most = w.getMostComparator();

	        Comparator<Word> least = w.getLeastComparator();
			
	        int size = sll.size();
			for(int i = 0; i < size; i++)
			{
				 
				//this gets the total word count from the array list
				totalCount += sll.get(i).getCount();
				
			}
			// once total unique words is added up, sum it to the bannedWords counter and get final count
			int finalCount =  bannedCount + totalCount;
			System.out.println("Number of TOTAL words was: " + finalCount);
			
			System.out.println("");
			System.out.println("");
			
		
			// this prints out the number of unique words in the file
			System.out.println("Unique Words: "+ (sll.size()));
		
			System.out.println("");
			// this prints the global count of banned words
			System.out.println("Number of STOP words was: " + bannedCount);
			
			System.out.println("");
			
				
			
			System.out.println("The Complete list of words, sorted by most is: ");
			sll.sort(most);
			//Collections.sort(words, most);
			
			//this prints out the list of most seen words and if the size of the array is under 10 just print the whole list
			if(sll.size()  <= 10)
			{
				size = sll.size();
				for(int i = 0; i < size; i++)
				{
					
				
					System.out.println("" + (i + 1) + ":" + " " + sll.get(i).getWord() + " : " + sll.get(i).getCount() ); // this is most 10
				
				}
			}
			else {
					
					// if the list is bigger than 10, print only the top 10
				for(int i = 0; i < 10; i++)
				{
					
				
					//System.out.println("The Complete list of words, sorted by most is: " +  " " + i + ":" + " " + words.get(i).getWord()  + " :" + words.get(i).getCount()); // this is least 10
					System.out.println("" + (i + 1) + ":" + " " + sll.get(i).getWord() + " : " + sll.get(i).getCount() ); // this is most 10

			
				}
				
			}
			
			System.out.println("");
					
			sll.sort(least);
			//Collections.sort(words, least);
			
			System.out.println("The Complete list of words, sorted by least is: ");

			//this prints out the list of least seen words and if the size of the array is under 10 just print the whole list
			// if the list is bigger than 10, print only the top 10
			if(sll.size()  < 10)
			{
				size = sll.size();
				for(int i = 0; i < size; i++)
				{
					
				
				
					System.out.println( ""+ (i + 1) + ":" + " " + sll.get(i).getWord()  + " : " + sll.get(i).getCount()); // this is least 10
			
				}
				
			}
			else {
				
				// if the list is bigger than 10, print only the top 10
			for(int i = 0; i < 10; i++)
			{
				
			
				System.out.println( ""+ i + ":" + " " + sll.get(i).getWord()  + " : " + sll.get(i).getCount()); // this is least 10
		
			}
			}
			System.out.println("");

			

			//---------------------------------------------
			

	System.out.println("Total words in the document are: ");
		
			sll.sort();

			// this prints out the list of all the unique words seen in the file.
			size = sll.size();
			for(int i = 0; i < size; i++)
			{
			System.out.println("" + sll.get(i).getWord() + " : " + sll.get(i).getCount());
			}

			

		}
}


	/*----------------------------------------------------------------------------------------------------------------------------------------------------------------*/



