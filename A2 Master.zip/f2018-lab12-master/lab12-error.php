<?php 

?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <title>Chapter 12</title>

   <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link href='http://fonts.googleapis.com/css?family=Roboto' rel='stylesheet' type='text/css'>
    
    <link rel="stylesheet" href="css/lab12-ex06.css">
</head>

<body>

<header>
      <h1><span>Textbook</span> Browser</h1>
      <nav><img src="images/menu.png" alt="mobile menu icon"></nav>
</header>
    
<main class="container">
    <div class="cards">
      <section  class="card">

          <div class="card-content">
              <p>Sorry, that ISBN doesn't exist in our catalog</p>
          </div>

      </section >         
    </div>	
	
</main>    
</body>
</html>