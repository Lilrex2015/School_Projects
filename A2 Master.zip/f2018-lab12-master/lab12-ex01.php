<?php

?>
<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8"/>  
    <title>Lab 12</title>   
    <link href="https://fonts.googleapis.com/css?family=Open+Sans:400,400i,700,800" rel="stylesheet">    
    <link rel="stylesheet" href="css/lab12-ex01.css">
</head>
<body>
<main class="container">
    <div class="grid-container">
        <div class='box'>
            <h2>ADBE</h2>
            <h3>Adobe Systems Inc.</h3>
            <p>$240.36</p>
        </div>
        <div class='box'>
            <h2>APPL</h2>
            <h3>Apple Inc.</h3>
            <p>$218.32</p>
        </div>
        <div class='box'>
            <h2>ATVI</h2>
            <h3>Activision Blizzard</h3>
            <p>$75.42</p>
        </div>
        <div class='box'>
            <h2>AMZN</h2>
            <h3>Amazon.com Inc.</h3>
            <p>$1760.19</p>
        </div>
        <div class='box'>
            <h2>ADSK</h2>
            <h3>Autodesk Inc.</h3>
            <p>$135.25</p>
        </div>    
        <div class='box'>
            <h2>FB</h2>
            <h3>Facebook Inc.</h3>
            <p>$154.62</p>
        </div>   
        <div class='box'>
            <h2>GOOGL</h2>
            <h3>Alphabet Inc.</h3>
            <p>$1111.39</p>
        </div>     
        <div class='box'>
            <h2>MSFT</h2>
            <h3>Microsoft Corporation</h3>
            <p>$108.82</p>
        </div>           
    </div>
</main>   
</body>
</html>