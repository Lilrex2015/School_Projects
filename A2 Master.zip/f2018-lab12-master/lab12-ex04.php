<?php


?>
<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8"/>  
    <title>Lab 12</title>   
    <link href="https://fonts.googleapis.com/css?family=Open+Sans:400,400i,700,800" rel="stylesheet">    
    <link rel="stylesheet" href="css/lab12-ex04.css">
</head>
<body>
<main class="container">

    <div class="box"> 
<h1>Portfolio Overview</h1>
<div class="data">
    <?php

    ?>
</div>
    </div>

</main>   
</body>
</html>