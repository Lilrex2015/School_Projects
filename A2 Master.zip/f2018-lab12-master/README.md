# COMP 3512
### PHP 2 Lab 
Lab exercise files and instructions for PHP Arrays and Superglobals

**Please view `COMP3512 Lab12 Instructions.pdf` for instructions**

  
