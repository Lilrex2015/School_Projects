package com.P3Assignment4.www;


public class Stack<T extends Comparable<T>> extends BST<T> {

	
	
		
	public void push( T data)
		{
			addNode(data);
		}
		
		public T pop()
		{
			return deleteNode();
			
		}
		
	
		public T peek() {
			
			return get(0);
		}
		
		public boolean isEmpty() {
			
		 return size() == 0;
		}
		

		
		
		}
	

