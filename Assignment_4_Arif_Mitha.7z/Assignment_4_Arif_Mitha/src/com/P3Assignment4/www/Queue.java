package com.P3Assignment4.www;


public class Queue<T extends Comparable<T>> extends BST<T> 
{
	
	
	public void enqueue( T data)
	
	{
		addNode( data);
		
	}

	public T dequeue(T data)
	{
		return deleteNode(data);
	}
	public T peek()
	{
		return get(0);
	}
	public boolean isEmpty()
	{
		return size() == 0;
	}

}
