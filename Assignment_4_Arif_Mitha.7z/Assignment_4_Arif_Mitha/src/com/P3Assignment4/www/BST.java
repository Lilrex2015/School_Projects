package com.P3Assignment4.www;

import java.util.ArrayList;
import java.util.Iterator;

public class BST<T extends Comparable<T>> {

	


    private Node<T> root;

	
	
	public BST()
	{
	
	}
	
	
	public void addNode(T value)
	{
		if(root == null)
		{
			root  = new Node<T>();
			root.setData(value);
			return;
		}
		root.addNode(value);
	}
	
	public void addByNumber(String word, int freq)
	{
		// this will use the frequency count of the words to compare and  then add accordingly
		
		if(root == null)
		{
			root  = new Node<T>();
			root.setData(freq); // int and string should be wrapped in the Word object, and thus extracted after? or make a new method? .... I made a new method
			return;
		}
		root.addByNumber(word, freq);
	}


	public void addByLength(String word)
	{
		
		if(root == null)
		{
			root  = new Node<T>();
			root.setData(word);
			return;
		}
		root.addNode(word);
		
	}
	
	public void deleteNode (String[] words)
	{
		if(root == null)
		{
			return;
		}
		
		boolean isLeft = false;
		root.deleteNode(words, root, isLeft);
			
		}

	
	public Iterator<T> iterator()
	{
		ArrayList<T> list = new ArrayList<T>();

		// traverse the tree and build up the list
		if (root != null)
		{
			root.traverse(list);
		}

		Iterator<T> iterator = list.iterator();
		return iterator;
	}

	public String toString()
	{
		String str = "";
		Iterator<T> iterator = iterator();
		while (iterator.hasNext())
		{
			T value = iterator.next();
			str += value + ", ";
		}
		return str;
	}
}


