package com.P3Assignment4.www;

import java.io.File;
import java.io.FileNotFoundException;
import java.util.Scanner;

public class A4 {

	public static void main(String[] args) throws FileNotFoundException {
		//test();
		run();

	}
	
	public static void run() throws FileNotFoundException
	{
		//Scanner input = new Scanner (System.in);
		Scanner input = new Scanner (new File("src/inp0.txt"));
		BST<Word> bst = new BST<Word>();
		int value = 1;
		
		String[] stopWords = { 
		         "a", "about",  "all", "am", "an", "and",  "any", "are", "as", "at", 
		         "be", "been", "but", "by", "can", "cannot", "could", "did", "do", "does", 
		         "else", "for", "from", "get", "got", "had", "has", "have", "he", "her", 
		         "hers", "him", "his", "how", "i", "if", "in", "into", "is", "it", 
		         "its", "like", "more", "me", "my", "no", "now", "not", "of", "on", 
		         "one", "or", "our", "out", "said", "say", "says", "she", "so", "some",
		         "than", "that", "thats", "the", "their", "them", "then", "there", "these", "they", "this", 
		         "to", "too", "us", "upon", "was", "we", "were", "what", "with", "when", 
		         "where", "which", "while", "who", "whom", "why", "will", "you", "your", "up", "down", "left", "right",
		         "man", "woman", "would", "should", "dont", "after", "before", "im", "men"
		   };
		
		while(input.hasNext())
		{
			String s = input.next();	
			Word gg = new Word(s, value);
			//System.out.println(s);
			bst.addNode(gg);
			
		}
		
		
		System.out.println(bst + "1");
		// bst.deleteNode(stopWords);
		// bst.addByNumber();
		bst.deleteNode(stopWords);
		System.out.println(bst + "2");
		// bst.addByLength();
		System.out.println(bst + "3");
		
		input.close();
	}

	// TODO remove
	public static void test()
	{
		BST<String> bst = new BST<String>();
		bst.addNode("fee");
		bst.addNode("cc");
		bst.addNode("fum");
		bst.addNode("a");
		bst.addNode("fo");
		bst.addNode("k");
		bst.addNode("fi");
		System.out.println(bst);
	}
}
