package com.P3Assignment4.www;

import java.util.ArrayList;

/** Node class starting code. 
 *  COMP 2503 Winter 2018
 */
public class Node<T extends Comparable<T>>
{
   
    private T data;
    private Node<T> left;
    private Node<T> right;
    
    /**
     * Constructor for objects of class Node
     */
    public Node()
    {
       data = null;
       left = null;
       right  = null;
    }
    
    public T getData() 
    {
    	return data;
    	
    }
    public void setData(T o) 
    
    {
    	data = o;
    	
    }
    
    public Node<T> getLeft()
    {
    	return left;
    	
    }
    public void setLeft(Node<T> n)
    { 
    	left = n;
    	
    }
    
    
    public Node<T> getRight()
    {
    	return right;
    	
    }
    public void setRight(Node<T> n)
    { 
    	right = n;
    	
    }
    
    
    
    /*-------------------------------------------------------------------------------------------------------------------------------------------------*/
    
    /*-------------------------------------------------------------------------------------------------------------------------------------------------*/
    
    /*-------------------------------------------------------------------------------------------------------------------------------------------------*/
 
    public void addNode(T value)
    {
		int c = value.compareTo(data);
		
		if(c < 0)
		{
			
			if(left == null)
			{
				left = new Node<T>();
					left.setData(value);
			}
			
			else {
				
				left.addNode(value); 
			}
		}
		
		if( c > 0)
		{
			
			
			if(right == null)
			{
				right = new Node<T>();
					
				right.setData(value);
			}
			
			else {
				
				right.addNode(value); 
			}
		}
					
		
    }
    
    /*-------------------------------------------------------------------------------------------------------------------------------------------------*/
    
    /*-------------------------------------------------------------------------------------------------------------------------------------------------*/
    
    /*-------------------------------------------------------------------------------------------------------------------------------------------------*/
    
    public void addByNumber(String word, int freq)
    {
    	
    	//this is done after the banned words have been removed from the tree. 
    	// use words objects to get the frequency count and compare, and reorganize by count
    	int c =  freq;
    	
    	if( c < data)
    
    		if(left == null)
			{
				left = new Node<T>();
					left.setData(c);
			}
			
			else {
				
				Word gg = new Word(word, freq);
				left.addNode(gg); 
			}
    	
    	if( c > data)
		{
			
			
			if(right == null)
			{
				right = new Node<T>();
					
				right.setData(c);
			}
			
			else {
				
				
				Word gg = new Word(word, freq);
				right.addNode(gg); 
			}
		}
    }
    
    
    /*-------------------------------------------------------------------------------------------------------------------------------------------------*/
    
    /*-------------------------------------------------------------------------------------------------------------------------------------------------*/
        
    /*-------------------------------------------------------------------------------------------------------------------------------------------------*/
    
    
	public void deleteNode (String[] word, Node<T> root, boolean isLeft)  // think about this ... pretty sure at some point i should use a Words object
	{
		
	
		for(int i = 0; i < word.length; i++)
		
		{
			int check = word[i].compareTo((String) root.getData());
			if(check < 0)
			{
				left.deleteNode(word, root, isLeft);
			}
			
			if(check > 0)
			{
				right.deleteNode(word, root, isLeft);
			}
			
			if(check == 0)
			{
				Node<T> temp =  root;
				Node<T> temp2 =  temp;
				Node<T> temp3 =  temp;
				temp2 =  temp2.getRight();
				temp3 =  temp3.getLeft();
				temp.setData(null);
				root.setRight(temp2);
				root.setLeft(temp3);
				
				
			}
		}
		
		// if I'm going left
		// if (....) {
		
		left.deleteNode(word, this, true);
		//}
			
		// so if I'm deleting myself
			// if isLeft
		root.setLeft(left);
		// else
		root.setRight(left);
	}
	
	
	 
    /*-------------------------------------------------------------------------------------------------------------------------------------------------*/
	 
    /*-------------------------------------------------------------------------------------------------------------------------------------------------*/

    /*-------------------------------------------------------------------------------------------------------------------------------------------------*/
    
	

	public void addByLength(String word)
	{
		
		
		
	}

    /*-------------------------------------------------------------------------------------------------------------------------------------------------*/
	 
    /*-------------------------------------------------------------------------------------------------------------------------------------------------*/
	 
    /*-------------------------------------------------------------------------------------------------------------------------------------------------*/
	
	
	
    
    public void traverse(ArrayList<T> list)
    {
    	// also, for THIS node, we must do the thing
    	
    	list.add(data);
    	
    	// if left is there, let left do it's thing
    	
    	if(left != null)
    	{
    		
    		left.traverse(list);
    	}

    	
    	// if right is there, let right do it's thing
    	
     	if(right != null)
    	{
    		
    		right.traverse(list);
    	}
    	
    	
    }
    
    
    /*-------------------------------------------------------------------------------------------------------------------------------------------------*/
    
    /*-------------------------------------------------------------------------------------------------------------------------------------------------*/
    
    /*-------------------------------------------------------------------------------------------------------------------------------------------------*/
    
    public String toString() 
    {
        return "Node: " + getData();
    }
    
    
    /*-------------------------------------------------------------------------------------------------------------------------------------------------*/
    
    /*-------------------------------------------------------------------------------------------------------------------------------------------------*/
    
    /*-------------------------------------------------------------------------------------------------------------------------------------------------*/
}

