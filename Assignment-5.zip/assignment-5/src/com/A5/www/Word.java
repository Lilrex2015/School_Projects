package com.A5.www;


import java.util.Comparator;

public class Word implements Comparable<Word>, Comparator<Word> {
	
	private String word;
	private int count;
	
	public Word()
	{
		
	}
 
	public Word(String f, int x)
	{
		this.word = f;
		this.count = x;
		
	}

	public String getWord() {
		return word;
	}

	public void setWord(String word) {
		this.word = word;
	}

	public int getCount() {
		return count;
	}

	public void setCount(int count) {
		this.count = count;
	}

	public int compareTo(Word x) {
		return this.word.compareTo(x.getWord());
	}

	public int compare(Word item1, Word item2) {
		return item1.getWord().compareTo(item2.getWord());
	}

	public boolean equals(Object other) 
	{
		if (other == this)
		{
			return true;
		}
		if (other == null)
		{
			return false;
		}

		Word w = (Word) other;
		return this.getWord().equals(w.getWord());
	}
	
	public String toString()
	{
		return word + " : " + word.length() + " : " + count;
	}

	public Comparator<Word> getMostToLeastComparator() {
		
		Comparator<Word> most = new Comparator<Word>() {
			
			public int compare(Word o1, Word o2) {
				Integer int1 = o1.getCount();
				Integer int2 = o2.getCount();

				int tie = int2.compareTo(int1);
				if(tie == 0)
				{
					return o1.getWord().compareTo(o2.getWord());
				}
				else {
					
					return tie;
				}
				
			}
		};
		return most;
	}
	
	public Comparator<Word> getLeastToMostComparator() {
		
		Comparator<Word> least = new Comparator<Word>() {
			
			public int compare(Word o1, Word o2) {
				Integer int1 = o1.getCount();
				Integer int2 = o2.getCount();

				int tie = int1.compareTo(int2);
				
				if(tie == 0 )
				{
					return o1.getWord().compareTo(o2.getWord());
				}
				else {
					return tie;
				}
			}
		};
		return least;
	}

	public Comparator<Word> getLongestToShortestComparator() {
		
		Comparator<Word> most = new Comparator<Word>() {
			
			public int compare(Word o1, Word o2) {
				Integer int1 = o1.getWord().length();
				Integer int2 = o2.getWord().length();

				int tie = int2.compareTo(int1);
				if(tie == 0)
				{
					return o1.getWord().compareTo(o2.getWord());
				}
				else {
					return tie;
				}
				
			}
		};
		return most;
	}
	
}
